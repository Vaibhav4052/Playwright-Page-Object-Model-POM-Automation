class LoginPage:
    def __init__(self, page):
        self.page = page

    def login(self, email, password):
        self.page.fill("#email", email)
        self.page.fill("#password", password)
        self.page.click("#login-btn")
